INSERT INTO 
	TBL_EMPLOYEES (file_name, input_type, environment)
VALUES
  	('ICAS_File1', 'ISO', 'QA101'),
  	('ICAS_File1', 'NCH', 'UA101');