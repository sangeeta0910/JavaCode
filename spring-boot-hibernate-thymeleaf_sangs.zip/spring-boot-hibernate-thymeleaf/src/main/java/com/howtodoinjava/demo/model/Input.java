package com.howtodoinjava.demo.model;

public enum Input {
    ISO,
    INACHA,
    SWIFT
}
