package com.howtodoinjava.demo.model;

public enum Environment {
    INT101,
    UA101,
    UA201,
    UA202,
    QA102,
    QA101,
    VAM101

}
